/** "just now", "5 min ago", "3 h ago", "2 d ago", then a plain date — like a neighbourhood feed. */
export function timeAgo(value: string | Date, now: Date = new Date()): string {
  const then = new Date(value);
  const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);
  if (seconds < 45) return 'just now';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days} d ago`;
  return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: then.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}
